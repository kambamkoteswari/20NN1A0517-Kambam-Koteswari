# Video-Conference-App
This is a full stack Video Conference App made using MERN stack.

The backend of this project has been made using NODE js and Express Server. 

Socket.io has been used to make the web connections.

Peer js has been used to make the peer-to-peer connections. 

This website has a very simple UI which enables muliple users to connect for a video call, by providing each of them a seperate userID. 
Use `npm start` or `nodemon index.js` to start the server on PORT: 5000. Also use `npm start` on the client folder to start the frontend react app.
